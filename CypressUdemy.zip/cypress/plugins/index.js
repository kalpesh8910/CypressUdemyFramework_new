const { config } = require("bluebird");

// This opetion is called when a project is opned or re opened  (due to project config changes)

module.exports = (on, config) => {

    // 'on' is used to hook into various events cypress emits
    // 'config' is the resolved Cypress config

}

